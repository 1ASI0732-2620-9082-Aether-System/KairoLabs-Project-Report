# KairoLabs: Core Integration Tests

Proyecto para Visual Studio Code que ejecuta **API ASP.NET Core 10 + MySQL real + gateways Axios del frontend**, sin mocks y sin acceder a producción.

## Ejecutar en este equipo

1. Abrir `KairoLabs-Integration.code-workspace` con Visual Studio Code.
2. Abrir `tests/integration.test.mjs`.
3. Pulsar **F5** y seleccionar **KairoLabs: ejecutar integracion real**. También puede utilizarse **Terminal → Ejecutar tarea → KairoLabs: ejecutar 14 pruebas de integracion**.
4. Esperar a que aparezcan los resultados y el paso `[5/5]`, que cierra la API, elimina la base temporal y apaga MySQL.

Alternativa desde la terminal integrada, ubicada en la carpeta del proyecto:

```powershell
npm test
```

Este equipo ya dispone de las herramientas preparadas en `.tooling`, en el workspace original. El proyecto las detecta automáticamente. No requiere ejecutar manualmente la API o MySQL. Los puertos locales **5187** y **33079** deben estar libres; el ejecutor comprueba esto antes de iniciar.

## Si se extrae el ZIP en otra ubicación o equipo

Se requiere Windows x64 y Node.js 24 o posterior. Si no se detectan .NET 10 y MySQL en las rutas locales de preparación, ejecutar una vez:

```powershell
npm run setup
npm test
```

La preparación descarga los archivos oficiales de .NET y MySQL en `.runtime`, comprueba sus checksums y los extrae sin instalar servicios ni cambiar la instalación global. Requiere Internet y espacio para ambos runtimes. El primer `npm test` restaura NuGet y ejecuta `npm ci --ignore-scripts` dentro de `frontend/`. No ejecutar los scripts originales de inicio de la aplicación: el proyecto utiliza exclusivamente `vite.integration.config.js`.

## Resultado real de la versión entregada

**14 pruebas ejecutadas, 14 aprobadas y 0 fallidas.** Código de salida 0. Se corrigieron los dos defectos encontrados en la ejecución anterior:

- **IT-WEB-02:** el backend permite el origen local y `https://kairo-labs-frontend.vercel.app`, y mantiene el rechazo de un origen ajeno.
- **IT-SEC-01:** `GET /api/v1/devices` devuelve 401 sin token, con token inválido, firma alterada, emisor o audiencia incorrectos y token expirado. Devuelve 200 con JWT válido.

La suite está aprobada para sus 14 casos. Se conservaron las expectativas y se corrigió el backend. Los casos funcionales utilizan ahora el JWT real obtenido en la preparación. Las correcciones están aplicadas localmente y aún no están publicadas ni desplegadas.

## Evidencias y capturas

- `evidence/latest.tap`: salida completa de Node, con el resumen 14/14/0.
- `evidence/before-fix/`: ejecución anterior con 12 aprobadas y 2 fallidas.
- `evidence/results.json`: resultados por identificador y versión del entorno.
- `evidence/http-transcript.json`: solicitudes y respuestas de datos sintéticos, con contraseñas y tokens redactados.
- `evidence/startup-diagnostics.txt`: incidencia de migraciones detectada durante el arranque, que se recupera mediante el reintento del propio backend.
- `evidence/build-warnings.txt`: advertencias NuGet producidas al compilar.
- `6.1.2-Core-Integration-Tests.md`: apartado del informe actualizado.

Las evidencias se regeneran al ejecutar las pruebas; los extractos de diagnóstico corresponden a la ejecución entregada.

Para la captura, dejar visible el código de las pruebas y la terminal integrada. Capturar el resumen completo con 14 aprobadas y 0 fallidas. Texto sugerido:

> Figura 6.1.2-1. Revalidación de pruebas de integración de KairoLabs mediante API ASP.NET Core y MySQL locales, con gateways reales del frontend. Tras corregir CORS y autenticación JWT, se ejecutaron 14 casos: 14 aprobados y 0 fallidos.

## Aislamiento y trazabilidad

El backend parte de MediTrackSensor, commit `c6c0bc7cfe03014f0ec311d8fb6c6a3ae8dddb03`. `Program.cs` incorpora el origen CORS de KairoLabs, validación JWT y autenticación obligatoria por defecto; `UsersController.cs` declara explícitamente login y registro públicos. También se mantienen los endpoints de salud y la redirección inicial como públicos. El `.csproj` no cambia. Los archivos `appsettings*.json` contienen configuración local sin credenciales de producción. La clave JWT de pruebas y la conexión local se fijan durante la ejecución y se restauran al terminar. `cors-jwt.patch` permite revisar y aplicar las dos modificaciones C# sobre el commit base.

El frontend corresponde al commit base `0d2c76f8fb20405e6ea271dfe505222cc7cc1aa2` con la corrección local de `Device.toNum()` del apartado 6.1.1. La configuración de integración compila los gateways y assemblers sin modificar sus funciones y fija `VITE_USE_MOCKS=false` y la URL local. Se utiliza Axios real y un adaptador de `sessionStorage` para Node; no se monta la interfaz Vue ni se ejecuta un navegador.

Cada ejecución crea una base con prefijo `kairolabs_it_` e identificador aleatorio. Las pruebas emplean HTTP real y consultas MySQL independientes para comprobar la persistencia. El script elimina solo la base creada por esa ejecución y termina únicamente los procesos que inició. Los archivos de datos del servidor portátil permanecen en `.runtime`, excluidos del ZIP y de Git.

No se acredita todavía validación de navegador, aplicación móvil, autorización completa entre entidades ni pruebas del backend adaptado a un commit propio de KairoLabs. La autenticación obligatoria requiere que los consumidores envíen JWT en los endpoints protegidos; los flujos anónimos que antes consultaban directorios operativos, como el listado de administradores, necesitan adaptarse al integrar el cambio. `provenance.json` registra los archivos de referencia, hashes y modificaciones locales.

## Referencias de herramientas

- [.NET: instalación en Windows](https://learn.microsoft.com/en-us/dotnet/core/install/windows).
- [MySQL Community Server](https://dev.mysql.com/downloads/mysql/8.4.html).
- [Inicialización del directorio de MySQL](https://dev.mysql.com/doc/refman/8.4/en/data-directory-initialization.html).
