# KairoLabs: Core Entities Unit Tests

Proyecto autónomo para Visual Studio Code, preparado para el apartado 6.1.1 del reporte.

## Abrir y ejecutar

1. Abrir `KairoLabs-Tests.code-workspace` con Visual Studio Code. Si se descargó el ZIP, extraerlo primero.
2. Abrir `tests/core-entities.test.mjs` desde el explorador.
3. Pulsar **F5** y seleccionar **KairoLabs: ejecutar y depurar pruebas**, si se solicita. Los resultados aparecen en la terminal integrada. También se puede usar **Terminal → Ejecutar tarea → KairoLabs: ejecutar 20 pruebas unitarias**.

Se requiere Node.js 24 o posterior disponible en PATH. No se necesita `npm install`, extensiones adicionales, backend, conexión a Internet ni base de datos.

Alternativa desde la terminal integrada:

```powershell
npm test
```

## Resultado esperado de esta versión

**20 casos ejecutados, 20 aprobados y 0 fallidos.** La ejecución termina con código 0.

Se corrigió `Device.toNum()` para tratar `null`, `undefined` y cadenas vacías o compuestas por espacios en blanco como ausencia de lectura (`unknown`). Una temperatura real de cero, numérica o como cadena, conserva su clasificación `critical`. Los casos UT-DEV-10 y UT-DEV-11 mantienen sus expectativas originales y añaden regresiones para estas variantes.

Estas son pruebas del dominio del frontend. No acreditan pruebas del backend, integración con MySQL, cobertura total ni validación completa del producto.

## Evidencia para el informe

- Mostrar el archivo de pruebas y la terminal integrada, con los nombres de los casos y el resumen completo.
- Mostrar el resumen con las 20 pruebas aprobadas. La evidencia inicial de los dos fallos se conserva en `evidence/before-fix.tap` para documentar la corrección.
- Ejecutar **Terminal → Ejecutar tarea → KairoLabs: guardar reporte TAP** para actualizar `evidence/latest.tap`, o usar `npm run test:report`.
- Conservar los reportes inicial y posterior a la corrección.

Texto sugerido:

> Figura 6.1.1-1. Revalidación de pruebas unitarias del dominio del frontend de KairoLabs en Visual Studio Code mediante Node.js. Tras corregir la clasificación de temperaturas ausentes, se ejecutaron 20 casos: 20 aprobados y 0 fallidos.

## Código evaluado y procedencia

La carpeta `src/` contiene tres archivos de dominio basados en KairoLabs-Frontend, commit `0d2c76f8fb20405e6ea271dfe505222cc7cc1aa2`, revisado el 30 de octubre de 2026. `device.entity.js` incorpora la corrección local de temperaturas ausentes; los otros dos archivos conservan el contenido original. La corrección todavía no tiene commit ni está publicada en GitHub:

- `src/monitoring/domain/model/device.entity.js`
- `src/subscriptions/domain/model/subscription.entity.js`
- `src/iam/domain/sign-in.command.js`

Los hashes actuales y originales, la referencia del repositorio y la descripción de la corrección se guardan en `provenance.json`. Este proyecto reproduce la versión corregida localmente; no sincroniza automáticamente cambios posteriores del frontend ni constituye una instalación completa de la aplicación. No carga `api.js` ni la configuración de Vite. El cambio aplicable al commit base se incluye en `temperature-missing-values.patch`.

Las tareas y F5 fijan la ruta al código incluido. Para probar otra copia desde una terminal nueva:

```powershell
$env:KAIROLABS_FRONTEND_ROOT = 'C:\ruta\KairoLabs-Frontend'
npm test
```

Antes de atribuir los resultados a una nueva versión, registrar el commit de esa copia y regenerar la evidencia.
